import pika
import time
import random

MAX_RETRIES = 3

def notify_customer(order_id):
    if random.random() < 0.3:
        raise Exception("Notification failed (simulated).")
    print(f"[Notification] Customer notified for order ID: {order_id}")

def callback(ch, method, properties, body):
    order_id = body.decode()
    print(f"[Notification] Received order ID: {order_id}")
    retries = 0
    while retries < MAX_RETRIES:
        try:
            time.sleep(2)
            notify_customer(order_id)
            ch.basic_ack(delivery_tag=method.delivery_tag)
            delivery_channel.basic_publish(exchange='', routing_key='delivery_queue', body=order_id)
            break
        except Exception as e:
            print(f"[Notification] Error: {e}, retrying...")
            retries += 1
            time.sleep(2)
    else:
        print(f"[Notification] Failed to notify customer after {MAX_RETRIES} attempts.")

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()
channel.queue_declare(queue='notification_queue')

delivery_connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
delivery_channel = delivery_connection.channel()
delivery_channel.queue_declare(queue='delivery_queue')

channel.basic_consume(queue='notification_queue', on_message_callback=callback)

print("[Notification] Waiting for notifications...")
channel.start_consuming()
