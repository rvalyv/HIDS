import pika
import time

def callback(ch, method, properties, body):
    order_id = body.decode()
    print(f"[Chef] Started cooking order ID: {order_id}")
    time.sleep(3)  # simulate cooking
    print(f"[Chef] Finished cooking order ID: {order_id}")

    ch.basic_ack(delivery_tag=method.delivery_tag)

    notify_channel.basic_publish(exchange='', routing_key='notification_queue', body=order_id)

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()
channel.queue_declare(queue='chef_queue')

notify_connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
notify_channel = notify_connection.channel()
notify_channel.queue_declare(queue='notification_queue')

channel.basic_consume(queue='chef_queue', on_message_callback=callback)

print("[Chef] Waiting for orders...")
channel.start_consuming()