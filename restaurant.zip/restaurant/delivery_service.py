import pika
import time
import random

MAX_RETRIES = 3

def alert_delivery(order_id):
    if random.random() < 0.2:
        raise Exception("Delivery guy not available (simulated).")
    print(f"[Delivery] Delivery guy informed for order ID: {order_id}")

def callback(ch, method, properties, body):
    order_id = body.decode()
    print(f"[Delivery] Preparing for order ID: {order_id}")
    retries = 0
    while retries < MAX_RETRIES:
        try:
            time.sleep(2)
            alert_delivery(order_id)
            ch.basic_ack(delivery_tag=method.delivery_tag)
            break
        except Exception as e:
            print(f"[Delivery] Error: {e}, retrying...")
            retries += 1
            time.sleep(2)
    else:
        print(f"[Delivery] Failed to alert delivery guy after {MAX_RETRIES} attempts.")

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()
channel.queue_declare(queue='delivery_queue')

channel.basic_consume(queue='delivery_queue', on_message_callback=callback)

print("[Delivery] Waiting for delivery tasks...")
channel.start_consuming()
