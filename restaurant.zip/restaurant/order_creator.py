import pika
import uuid

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()
channel.queue_declare(queue='chef_queue')

order_id = str(uuid.uuid4())
print(f"[Order] Placing order ID: {order_id}")
channel.basic_publish(exchange='', routing_key='chef_queue', body=order_id)

connection.close()
