#!/bin/bash

# Host-Based Intrusion Detection System (HIDS)

# Function to get file type
get_file_type() {
    if [ -L "$1" ]; then
        echo "SYMLINK"
    elif [ -d "$1" ]; then
        echo "DIRECTORY"
    elif [ -f "$1" ]; then
        echo "REGULAR"
    else
        echo "UNKNOWN"
    fi
}

# Function to get file info
get_file_info() {
    local file="$1"
    local type=$(get_file_type "$file")
    local checksum=""
    if [ "$type" == "REGULAR" ]; then
        checksum=$(md5sum "$file" | awk '{print $1}')
    fi
    local name=$(basename "$file")
    local ctime=$(stat -c %Z "$file" 2>/dev/null || echo "N/A")
    local mtime=$(stat -c %Y "$file")
    local links=$(stat -c %h "$file")
    echo "$file|$name|$type|$ctime|$mtime|$links|$checksum"
}

# Evaluate function to scan system and create config file
Evaluate() {
    local output_file="$1"
    local scan_dir="$2"

    # Clear output file
    > "$output_file"

    if [ -n "$scan_dir" ]; then
        # Scan single directory
        if [ ! -d "$scan_dir" ]; then
            echo "Error: Directory $scan_dir does not exist"
            exit 1
        fi
        find "$scan_dir" | while read -r file; do
            if [ -f "$file" ] || [ -d "$file" ] || [ -L "$file" ]; then
                get_file_info "$file" >> "$output_file"
            fi
        done
    else
        # Check if HIDS-config exists
        if [ ! -f "HIDS-config" ]; then
            echo "Error: HIDS-config file not found"
            exit 1
        fi
        # Collect exclude paths from HIDS-config
        EXCLUDES=()
        while read -r line; do
            directive=$(echo "$line" | awk '{print $1}')
            path=$(echo "$line" | awk '{print $2}')
            if [ "$directive" == "exclude" ]; then
                EXCLUDES+=("$path")
            fi
        done < HIDS-config

        # Scan include paths
        while read -r line; do
            directive=$(echo "$line" | awk '{print $1}')
            path=$(echo "$line" | awk '{print $2}')
            if [ "$directive" == "include" ]; then
                if [ ! -d "$path" ]; then
                    echo "Warning: Include path $path does not exist"
                    continue
                fi
                find "$path" | while read -r file; do
                    skip=false
                    for exclude in "${EXCLUDES[@]}"; do
                        if [[ "$file" == "$exclude"* ]]; then
                            skip=true
                            break
                        fi
                    done
                    if ! $skip; then
                        if [ -f "$file" ] || [ -d "$file" ] || [ -L "$file" ]; then
                            get_file_info "$file" >> "$output_file"
                        fi
                    fi
                done
            fi
        done < HIDS-config
    fi
    echo "[INFO] Evaluation completed, output written to $output_file"
}

# CreateVer function to create versioned config file
CreateVer() {
    local input_file="$1"
    local output_name="$2"

    if [ ! -f "$input_file" ]; then
        echo "Error: Input file $input_file does not exist"
        exit 1
    fi

    cp "$input_file" "$output_name"
    echo "[INFO] Configuration file $output_name created from $input_file"
}

# Compare function to compare two config files
Compare() {
    local old_file="$1"
    local new_file="$2"

    if [ ! -f "$old_file" ] || [ ! -f "$new_file" ]; then
        echo "Error: One of the configuration files does not exist"
        exit 1
    fi

    echo "===== MODIFIED OR NEW FILES ====="
    while IFS= read -r new_line; do
        path=$(echo "$new_line" | cut -d "|" -f 1)
        match=$(grep "^$path|" "$old_file")
        if [ -z "$match" ]; then
            echo "[NEW] $new_line"
        elif [ "$new_line" != "$match" ]; then
            echo "[MODIFIED] $new_line"
        fi
    done < "$new_file"


    echo ""
    echo "===== DELETED FILES ====="
    while IFS= read -r old_line; do
        path=$(echo "$old_line" | cut -d "|" -f 1)
        match=$(grep "^$path|" "$new_file")
        if [ -z "$match" ]; then
            echo "[DELETED] $old_line"
        fi
    done < "$old_file"
    echo "[INFO] Comparison completed"
}

# Report function to save comparison to file
Report() {
    local old_file="$1"
    local new_file="$2"
    local report_file="${3:-Report}"

    if [ ! -f "$old_file" ] || [ ! -f "$new_file" ]; then
        echo "Error: One of the configuration files does not exist"
        exit 1
    fi

    echo "===== MODIFIED OR NEW FILES =====" > "$report_file"
    while IFS= read -r new_line; do
        path=$(echo "$new_line" | cut -d "|" -f 1)
        match=$(grep "^$path|" "$old_file")
        if [ -z "$match" ]; then
            echo "[NEW] $new_line" >> "$report_file"
        elif [ "$new_line" != "$match" ]; then
            echo "[MODIFIED] $new_line" >> "$report_file"
        fi
    done < "$new_file"

    echo "" >> "$report_file"
    echo "===== DELETED FILES =====" >> "$report_file"
    while IFS= read -r old_line; do
        path=$(echo "$old_line" | cut -d "|" -f 1)
        match=$(grep "^$path|" "$new_file")
        if [ -z "$match" ]; then
            echo "[DELETED] $old_line" >> "$report_file"
        fi
    done < "$old_file"

    echo "[INFO] Report saved to $report_file"
}

# Check if the first argument is a function name
if declare -f "$1" > /dev/null; then
    # Call the function with remaining arguments
    case "$1" in
        Evaluate)
            if [ $# -eq 2 ]; then
                "$1" "$2"
            elif [ $# -eq 3 ]; then
                "$1" "$3" "$2"
            else
                echo "Usage: $0 Evaluate [dir] output_file"
                exit 1
            fi
            ;;
        CreateVer)
            if [ $# -eq 3 ]; then
                "$1" "$2" "$3"
            else
                echo "Usage: $0 CreateVer input_file output_file"
                exit 1
            fi
            ;;
        Compare)
            if [ $# -eq 3 ]; then
                "$1" "$2" "$3"
            else
                echo "Usage: $0 Compare old_file new_file"
                exit 1
            fi
            ;;
        Report)
            if [ $# -eq 3 ]; then
                "$1" "$2" "$3"
            elif [ $# -eq 4 ]; then
                "$1" "$2" "$3" "$4"
            else
                echo "Usage: $0 Report old_file new_file [report_file]"
                exit 1
            fi
            ;;
        *)
            echo "Error: Function $1 is not supported for direct invocation"
            exit 1
            ;;
    esac
else
    # Original option-based logic
    case "$1" in
        -c)
            if [ $# -ne 2 ]; then
                echo "Usage: $0 -c config_file"
                exit 1
            fi
            Evaluate temp_config.txt
            CreateVer temp_config.txt "$2"
            rm temp_config.txt
            ;;
        -d)
            if [ $# -ne 3 ]; then
                echo "Usage: $0 -d dir config_file"
                exit 1
            fi
            Evaluate temp_new.txt "$2"
            Compare "$3" temp_new.txt
            rm temp_new.txt
            ;;
        -o)
            if [ $# -ne 2 ]; then
                echo "Usage: $0 -o config_file"
                exit 1
            fi
            Evaluate temp_new.txt
            Report "$2" temp_new.txt
            rm temp_new.txt
            ;;
        "")
            echo "Usage: $0 [-c config_file] [-d dir config_file] [-o config_file] [Evaluate [dir] output_file] [CreateVer input_file output_file] [Compare old_file new_file] [Report old_file new_file [report_file]] [config_file]"
            echo "  -c config_file : Create a new configuration file"
            echo "  -d dir config_file : Check only the directory dir (full path)"
            echo "  -o config_file : Write report to file Report"
            echo "  Evaluate [dir] output_file : Scan HIDS-config or dir and write to output_file"

            echo "  CreateVer input_file output_file : Copy input_file to output_file"
            echo "  Compare old_file new_file : Compare two config files and print to console"
            echo "  Report old_file new_file [report_file] : Compare two config files and save to report_file (default: Report)"
            echo "  config_file : Print report to console"
            exit 1
            ;;
        *)
            if [ $# -ne 1 ]; then
                echo "Usage: $0 config_file"
                exit 1
            fi
            Evaluate temp_new.txt
            Compare "$1" temp_new.txt
            rm temp_new.txt
            ;;
    esac
fi

